Primitive 3D Raycasting graphics engine written by Josh Rees-Jones

This primitive raycaster uses the concept of raycasting to create a 3D perspective on a 2D map.

This project is very buggy, but keep in mind that I learned graphics development in a week and learned and implemented raycasting in 3 days.

SOME BUGS (but certainly not all):
Touching walls crashes the game
Jumpy movement at some angles
Skewed walls and openings
Rendering walls behind the actual wall - happens in DDA
Many more

Move with WASD. Left and right arrow keys crash the game. Press escape or click X to exit.

My roommate Bradley King helped with the math
lodev.org, stackexchange.com, and google.com were used

This raycaster REQUIRES Pygame!
I got mine at:
https://bitbucket.org/pygame/pygame/downloads

My roommate helped me with rotating a vector around the origin a number of radians:
[ cos(a) -sin(a) ]
[ sin(a)  cos(a) ]

Credits:
http://www.pygame.org/news.html
http://lodev.org/cgtutor/raycasting.html
http://inventwithpython.com/makinggames.pdf
Lode Vandevenne
Bradley King
Daniel Chiquito